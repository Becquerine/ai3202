python assignment8.py >> someOutputFile

You can run this program using the command specified in the writeup.
I wrote this using Python 3.5.0. It appears to work in Python 2.7.6,
but prints to different precisions.

